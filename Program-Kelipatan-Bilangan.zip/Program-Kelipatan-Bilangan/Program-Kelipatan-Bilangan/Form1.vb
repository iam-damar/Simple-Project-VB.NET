﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        BtnUlangi.Enabled = False

        Me.CenterToScreen()

    End Sub

    Private Sub BtnHitung_Click(sender As Object, e As EventArgs) Handles BtnHitung.Click

        If TxtInputAngka.Text = "" Or TxtInputKelipatan.Text = "" Or TxtJumlahKelipatan.Text = "" Then
            MsgBox("Kolom isian ada yang kosong!", MsgBoxStyle.OkOnly)
        Else
            BtnUlangi.Enabled = True

            Dim InputAngka, n, InputKelipatan, JumlahKelipatan As Double

            InputAngka = TxtInputAngka.Text
            InputKelipatan = TxtInputKelipatan.Text
            JumlahKelipatan = TxtJumlahKelipatan.Text

            ListAngkaKelipatan.Items.Add("index" & vbTab & "Angka-Kelipatan")
            ListAngkaKelipatan.Items.Add("_______________________")

            n = 1

            Do
                InputAngka = InputAngka * InputKelipatan

                ListAngkaKelipatan.Items.Add(n & vbTab & InputAngka)

                n = n + 1
            Loop Until n = JumlahKelipatan + 1
        End If

    End Sub

    Private Sub BtnUlangi_Click(sender As Object, e As EventArgs) Handles BtnUlangi.Click

        ListAngkaKelipatan.Items.Clear()

        TxtInputAngka.Text = ""
        TxtInputKelipatan.Text = ""
        TxtJumlahKelipatan.Text = ""

        BtnUlangi.Enabled = False

    End Sub
End Class
