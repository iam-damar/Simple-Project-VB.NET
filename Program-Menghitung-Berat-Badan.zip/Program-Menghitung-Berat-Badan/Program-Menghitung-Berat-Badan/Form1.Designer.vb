﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtTinggiBadan = New System.Windows.Forms.TextBox()
        Me.TxtBeratBadan = New System.Windows.Forms.TextBox()
        Me.TxtBMI = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.BtnHitung = New System.Windows.Forms.Button()
        Me.BtnReset = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(19, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(165, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Tinggi Badan (Meter)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(22, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(137, 18)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Berat Badan (Kg)"
        '
        'TxtTinggiBadan
        '
        Me.TxtTinggiBadan.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtTinggiBadan.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTinggiBadan.Location = New System.Drawing.Point(196, 20)
        Me.TxtTinggiBadan.Name = "TxtTinggiBadan"
        Me.TxtTinggiBadan.Size = New System.Drawing.Size(100, 17)
        Me.TxtTinggiBadan.TabIndex = 2
        '
        'TxtBeratBadan
        '
        Me.TxtBeratBadan.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtBeratBadan.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtBeratBadan.Location = New System.Drawing.Point(196, 63)
        Me.TxtBeratBadan.Name = "TxtBeratBadan"
        Me.TxtBeratBadan.Size = New System.Drawing.Size(100, 17)
        Me.TxtBeratBadan.TabIndex = 3
        '
        'TxtBMI
        '
        Me.TxtBMI.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TxtBMI.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtBMI.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtBMI.Location = New System.Drawing.Point(196, 107)
        Me.TxtBMI.Name = "TxtBMI"
        Me.TxtBMI.ReadOnly = True
        Me.TxtBMI.Size = New System.Drawing.Size(100, 17)
        Me.TxtBMI.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(22, 107)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 18)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "BMI"
        '
        'BtnHitung
        '
        Me.BtnHitung.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.BtnHitung.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnHitung.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnHitung.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnHitung.Location = New System.Drawing.Point(25, 155)
        Me.BtnHitung.Name = "BtnHitung"
        Me.BtnHitung.Size = New System.Drawing.Size(109, 42)
        Me.BtnHitung.TabIndex = 6
        Me.BtnHitung.Text = "Hitung"
        Me.BtnHitung.UseVisualStyleBackColor = False
        '
        'BtnReset
        '
        Me.BtnReset.BackColor = System.Drawing.Color.IndianRed
        Me.BtnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnReset.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnReset.Location = New System.Drawing.Point(206, 155)
        Me.BtnReset.Name = "BtnReset"
        Me.BtnReset.Size = New System.Drawing.Size(90, 42)
        Me.BtnReset.TabIndex = 7
        Me.BtnReset.Text = "Reset"
        Me.BtnReset.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(317, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(126, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "*) BMI (Body Mass Index)"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(317, 107)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(220, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "*) Tinggi Badan gunakan Titik (contoh : 1.72)"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(317, 127)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(233, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "*) Berat Badan juga gunakan Titik (contoh 65.2)"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Items.AddRange(New Object() {"BMI < 18.5   (Dibawah Normal)", "18.5 < BMI < 24.9 (Normal)", "25 < BMI < 29.9 (Berat Badan Berlebih)", "BMI >= 30 (Obesitas)"})
        Me.ListBox1.Location = New System.Drawing.Point(320, 20)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(201, 56)
        Me.ListBox1.TabIndex = 11
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(578, 216)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.BtnReset)
        Me.Controls.Add(Me.BtnHitung)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtBMI)
        Me.Controls.Add(Me.TxtBeratBadan)
        Me.Controls.Add(Me.TxtTinggiBadan)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Program Pengukuran Berat Badan"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TxtTinggiBadan As TextBox
    Friend WithEvents TxtBeratBadan As TextBox
    Friend WithEvents TxtBMI As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents BtnHitung As Button
    Friend WithEvents BtnReset As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents ListBox1 As ListBox
End Class
