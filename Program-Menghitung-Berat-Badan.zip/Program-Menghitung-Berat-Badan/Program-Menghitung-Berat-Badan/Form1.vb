﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        BtnReset.Enabled = False

        Me.CenterToScreen()

    End Sub

    Private Sub BtnHitung_Click(sender As Object, e As EventArgs) Handles BtnHitung.Click

        If TxtTinggiBadan.Text = "" Or TxtBeratBadan.Text = "" Or TxtBMI.Text = "" Then

            BtnReset.Enabled = True

            Dim TinggiBadan, BeratBadan, BMI As Single

            TinggiBadan = TxtTinggiBadan.Text
            BeratBadan = TxtBeratBadan.Text

            BMI = (BeratBadan) / (TinggiBadan ^ 2)

            TxtBMI.Text = BMI
        Else
            MsgBox("Kolom ada yang kosong!", vbOKOnly)

        End If


    End Sub

    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles BtnReset.Click

        BtnReset.Enabled = False
        TxtTinggiBadan.Text = ""
        TxtBeratBadan.Text = ""
        TxtBMI.Text = ""


    End Sub
End Class
